from otree.api import *

doc = """
Intro.
"""

class Page1(Page):
    form_model = 'Page1'   
class Page2(Page):
    form_model = 'Page2'   
class Page3(Page):
    form_model = 'Page3'
class Page4(Page):
    form_model = 'Page4'
class Page5(Page):
    form_model = 'Page5'  

class Group(BaseGroup):
    pass

class Subsession(BaseSubsession):
    pass

class Player(BasePlayer):
    pass

class C(BaseConstants):
    NAME_IN_URL = 'Introduction'
    PLAYERS_PER_GROUP = None
    NUM_ROUNDS = 1


page_sequence = [Page1,Page2,Page3,Page4,Page5]