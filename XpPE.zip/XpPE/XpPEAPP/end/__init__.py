from otree.api import *

doc = """
Thanks.
"""

class Page1(Page):
    form_model = 'Page1'   

class Group(BaseGroup):
    pass

class Subsession(BaseSubsession):
    pass

class Player(BasePlayer):
    pass

class C(BaseConstants):
    NAME_IN_URL = 'Thanks!'
    PLAYERS_PER_GROUP = None
    NUM_ROUNDS = 1


page_sequence = [Page1]